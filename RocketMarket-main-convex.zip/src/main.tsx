import {createRoot} from "react-dom/client";
import {Auth0Provider} from "@auth0/auth0-react";
import {ConvexProviderWithAuth0} from "convex/react-auth0";
import {ConvexReactClient} from "convex/react";
import {createBrowserRouter, Outlet, RouterProvider} from "react-router-dom";
import {StrictMode} from "react";
import Footer from "./Footer";
import Header from "./Header";
import Basket from "./Buyer/Basket";
import BuyerRequestBrowser from "./Buyer/RequestBrowser";
import SupplierRequestBrowser from "./Supplier/RequestBrowser";
import BuyerRequestDetail from "./Buyer/RequestDetail";
import SupplierRequestDetail from "./Supplier/RequestDetail";

import ProductBrowser from "./Buyer/ProductBrowser";
import ProductDetail from "./Buyer/ProductDetail";
import "bootstrap/dist/css/bootstrap.min.css";
import Landing from "./Landing";
import PostLogin from "./PostLogin";
import RegistrationForm from "./RegistrationForm";
import PostLogout from "./PostLogout";
import Suspended from "./Suspended";
import AwaitingApproval from "./AwaitingApproval";
import VerifyPayment from "./Buyer/verifyPayment";

const deploymentURL = import.meta.env.VITE_CONVEX_URL;
const convex = new ConvexReactClient(deploymentURL);
const root = createRoot(document.getElementById("root")!);

const router = createBrowserRouter([
    {
        path: "/",
        element: <Root />,
        children: [
            {
                path: "/",
                element: <Landing />,
            },
            {
                path: "/postLogin",
                element: <PostLogin />,
            },
            {
                path: "/postLogout",
                element: <PostLogout />,
            },
            {
                path: "/registration",
                element: <RegistrationForm />,
            },
            {
                path: "/awaiting_approval",
                element: <AwaitingApproval />,
            },
            {
                path: "/suspended",
                element: <Suspended />,
            },
            {
                path: "/dashboard",
                element: <ProductBrowser />,
            },
            {
                path: "/basket",
                element: <Basket />,
            },
            {
                path: "/requests",
                element: <BuyerRequestBrowser />,
            },
            {
                path: "/requests/:requestId",
                element: <BuyerRequestDetail />,
            },
            {
                path: "/products",
                element: <ProductBrowser />,
            },
            {
                path: "/products/:materialMajor",
                element: <ProductDetail />,
            },
            {
                path: "/product/:materialsMajorSlug/:materialsMinorId",
                element: <ProductDetail />,
            },
            {
                path: "/verifyPayment",
                element: <VerifyPayment />,
            },
            // SUPPLIER
            {
                path: "/supplier",
                element: <SupplierRequestBrowser />,
            },
            {
                path: "/supplier/requests",
                element: <SupplierRequestBrowser />,
            },
            {
                path: "/supplier/requests/:requestId",
                element: <SupplierRequestDetail />,
            },
        ],
    },
]);

function Root() {
    return (
        <>
            <Header />
            <Outlet />
            <Footer />
        </>
    );
}

root.render(
    <Auth0Provider
        domain="jeffhemmen.eu.auth0.com"
        clientId="Xz83XCEOdybf6HLUp9F7U9J4lm3v7oeT"
        authorizationParams={{
            redirect_uri: window.location.origin + "/postLogin",
        }}
    >
        <ConvexProviderWithAuth0 client={convex}>
            <StrictMode>
                <RouterProvider router={router} />
            </StrictMode>
        </ConvexProviderWithAuth0>
    </Auth0Provider>
);
