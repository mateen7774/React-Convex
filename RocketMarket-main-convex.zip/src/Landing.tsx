import { LoginButton } from "./Auth0Buttons";

export default function Landing() {

    return <><h2>Landing page</h2>Get started <LoginButton /></>

}
