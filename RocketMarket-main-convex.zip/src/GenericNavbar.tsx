import {NavItem, Nav, Navbar} from "reactstrap";
import {NavLink} from "react-router-dom";

export default function GenericNavbar() {
    return (
        <Navbar>
            Generic
            <Nav>
                <NavItem>
                    <NavLink to="/">Home</NavLink>
                </NavItem>
            </Nav>
        </Navbar>
    );
}
