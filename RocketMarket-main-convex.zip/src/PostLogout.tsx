import {useQuery, useConvexAuth} from "convex/react";
import {api} from "../convex/_generated/api";
import {useEffect, useState} from "react";

export default function PostLogout() {
    const userInfo = useQuery(api.users.getInfo);
    const {isAuthenticated, isLoading} = useConvexAuth();
    const WAIT_TEXT = "Please wait...";
    const LOGOUT_TEXT = "You have successfully logged out.";
    const [text, setText] = useState(WAIT_TEXT);

    useEffect(() => {
        if (isLoading) {
            setText(WAIT_TEXT);
        }

        if (!isAuthenticated) {
            setText(LOGOUT_TEXT);
        }
    }, [userInfo]);

    return text;
}
