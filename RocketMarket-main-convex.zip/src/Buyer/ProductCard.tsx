import {Link} from "react-router-dom";
import {Doc} from "../../convex/_generated/dataModel";
import {Card, CardBody, CardText, CardTitle} from "reactstrap";

export default function ProductCard({materialMajor}: {materialMajor: Doc<"materialsMajor">}) {
    const fallbackImageUrl = "https://hushed-caiman-696.convex.cloud/api/storage/4b2d6bac-d0e3-4473-aa51-e9219629bf99";

    return (
        <Link to={"/products/" + materialMajor._id} key={materialMajor._id}>
            <Card style={{width: "20rem"}}>
                <CardBody>
                    <CardTitle tag="h5">{materialMajor.majorName}</CardTitle>
                </CardBody>
                <img src={materialMajor.imageUrl ?? fallbackImageUrl} alt={materialMajor.majorName} width="100%" />
                <CardBody>
                    <CardText>{materialMajor.majorDescription}</CardText>
                </CardBody>
            </Card>
            <br />
        </Link>
    );
}
