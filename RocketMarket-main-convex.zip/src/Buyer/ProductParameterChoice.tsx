import {ChangeEvent} from "react";

interface ParameterOption {
    name: string;
    possibleValues: Set<any>; // You might want to replace 'any' with a more specific type
    selected: string; // Replace 'any' with the actual type
    visible: boolean;
}

export default function ProductParameterChoice({
    parameterOptions,
    setParameterOptions,
    parameterName,
}: {
    parameterOptions: ParameterOption[];
    setParameterOptions: Function;
    parameterName: string;
}) {
    const myPossibleValues = [
        ...parameterOptions.filter((o) => {
            return o.name === parameterName;
        })[0].possibleValues,
    ];
    const mySelected = parameterOptions.filter((o) => {
        return o.name === parameterName;
    })[0].selected;
    const amIVisible = parameterOptions.filter((o) => {
        return o.name === parameterName;
    })[0].visible;

    const handleSelected = (e: ChangeEvent<HTMLInputElement>) => {
        const newParameterOptions = parameterOptions.slice();
        newParameterOptions.filter((o) => {
            return o.name === parameterName;
        })[0].selected = e.target.value;
        setParameterOptions(newParameterOptions);
    };

    if (!amIVisible) return;

    return (
        <li key={parameterName}>
            {parameterName}:
            <ul>
                {myPossibleValues.map((possibleValue) => {
                    return (
                        <li key={possibleValue}>
                            <input
                                type="radio"
                                name={possibleValue}
                                value={possibleValue}
                                id={"radio_" + possibleValue}
                                required
                                checked={possibleValue === mySelected}
                                onChange={handleSelected}
                            />
                            <label htmlFor={"radio_" + possibleValue}>{possibleValue === "_NONE" ? "None" : possibleValue}</label>
                        </li>
                    );
                })}
            </ul>
        </li>
    );
}
