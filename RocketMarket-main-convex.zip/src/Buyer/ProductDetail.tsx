import {useMutation, useQuery} from "convex/react";
import {api} from "../../convex/_generated/api";
import ProductParameterChoice from "./ProductParameterChoice";
import {useEffect, useState} from "react";
import {useParams} from "react-router-dom";
import {Doc, Id} from "../../convex/_generated/dataModel";

export default function ProductDetail() {
    interface ParameterOption {
        name: string;
        possibleValues: Set<any>; // You might want to replace 'any' with a more specific type
        selected: string; // Replace 'any' with the actual type
        visible: boolean;
    }

    const materialMajor = useParams().materialMajor as Id<"materialsMajor">;
    if (!materialMajor) throw new Error("No such materialMajor.");
    const materialCombinations = useQuery(api.products.getCombinations, {
        materialMajor,
    });
    const fallbackImageUrl = "https://hushed-caiman-696.convex.cloud/api/storage/4b2d6bac-d0e3-4473-aa51-e9219629bf99";
    const [parameterOptions, setParameterOptions] = useState<ParameterOption[]>([]);
    const addToBasketMutation = useMutation(api.basket.addToBasket);
    const [quantity, setQuantity] = useState(1);

    console.log(materialCombinations);

    useEffect(() => {
        if (materialCombinations && materialCombinations?.materialsMinor) {
            const newParameterOptions: ParameterOption[] = [];
            for (const materialMinor of materialCombinations?.materialsMinor) {
                for (const parameter of materialMinor.parameters) {
                    newParameterOptions[parameter.priority] = {
                        name: parameter.name,
                        possibleValues: new Set(),
                        selected: parameter.value,
                        visible: true,
                    };
                }
            }
            for (const parameterPriority in newParameterOptions) {
                for (const materialMinor of materialCombinations?.materialsMinor) {
                    let parameterNullable = true;
                    for (const parameter of materialMinor.parameters) {
                        if (parameter.name == newParameterOptions[parameterPriority].name) {
                            parameterNullable = false;
                            newParameterOptions[parameterPriority].possibleValues.add(parameter.value);
                        }
                    }
                    if (parameterNullable) newParameterOptions[parameterPriority].possibleValues.add(null);
                }
            }
            setParameterOptions(newParameterOptions);
        }
    }, [materialCombinations]);

    type SelectedParameters = Record<string, string>;
    const selectedParameters = parameterOptions.reduce<SelectedParameters>((acc, current) => {
        acc[current.name] = current.selected;
        return acc;
    }, {});

    const getSelectedMaterialMinor = () => {
        if (!materialCombinations || !materialCombinations?.materialsMinor) return null;
        eachMaterialMinor: for (const materialMinor of materialCombinations?.materialsMinor) {
            // iterate over every possible material
            // generate parameterMap
            const currentParameters = materialMinor.parameters.reduce((acc: string[], current: any) => {
                acc[current.name] = current.value;
                return acc;
            }, {});
            // compare maps
            if (selectedParameters.length != currentParameters.length) continue;
            for (const key in currentParameters) if (selectedParameters[key] != currentParameters[key]) continue eachMaterialMinor;
            return materialMinor;
        }
        return null;
    };
    const selectedMaterialMinor = getSelectedMaterialMinor();

    function handleAddToBasket(selectedMaterialMinor: Doc<"materialMinor">) {
        if (!selectedMaterialMinor || quantity < 1) return false;
        addToBasketMutation({
            materialMinor: selectedMaterialMinor._id,
            quantity: quantity,
        });
        setQuantity(1);
    }

    return (
        <>
            <div className="product_detail">
                <h2>{materialCombinations?.majorName}</h2>
                <div className="product_image">
                    <img src={fallbackImageUrl} />
                </div>
                <div className="product_description">Description: {materialCombinations?.majorDescription}</div>
                <div className="product_minor_selection">
                    {parameterOptions.map((parameterObject) => {
                        return (
                            <ProductParameterChoice
                                key={parameterObject.name}
                                parameterOptions={parameterOptions}
                                setParameterOptions={setParameterOptions}
                                parameterName={parameterObject.name}
                            />
                        );
                    })}
                </div>
                <div className="product_add_to_basket">
                    Selected: {selectedMaterialMinor?.minorName}.
                    <br />
                    Detail: {selectedMaterialMinor?.minorDescription}
                    <br />
                    Quantity: <input type="number" id="quantity" value={quantity} onChange={(e) => setQuantity(+e.target.value)} />
                    &nbsp;
                    <button onClick={() => handleAddToBasket(selectedMaterialMinor)} disabled={!selectedMaterialMinor}>
                        Add to order
                    </button>
                    <br />
                </div>
            </div>
        </>
    );
}
