import {Card, CardBody, CardSubtitle, CardTitle, ListGroup, ListGroupItem} from "reactstrap";
import Countdown from "../Countdown";
import {Doc} from "../../convex/_generated/dataModel";

export default function RequestCard({r}: {r: Doc<"requests">}) {
    return (
        <>
            <Card style={{width: "20rem"}}>
                <CardBody>
                    <CardTitle tag="h4">Request for max. {r.maxPrice} &euro;</CardTitle>
                    <CardSubtitle className="mb-2 text-muted" tag="h5">
                        Status: {r.status}
                    </CardSubtitle>
                </CardBody>
                <ListGroup flush>
                    <ListGroupItem>To deliver on {new Date(r.deliveryDate!).toDateString()}</ListGroupItem>
                    <ListGroupItem>
                        between {r.deliveryTimeSlot}h and {r.deliveryTimeSlot! + 2}h{" "}
                    </ListGroupItem>
                    <ListGroupItem>to: {r.deliveryLocation}</ListGroupItem>
                    <ListGroupItem tag="h6">
                        Timeout: <Countdown targetTime={r.initialTimeout || null} staticText={r.initialTimeout ? undefined : "--h --m --s"} />
                    </ListGroupItem>
                    <ListGroupItem tag="h6">
                        Bidding time: <Countdown targetTime={r.biddingTimeout || null} staticText={r.biddingTimeout ? undefined : "48h 00m 00s"} />
                    </ListGroupItem>
                </ListGroup>
            </Card>
            <br />
        </>
    );
}
