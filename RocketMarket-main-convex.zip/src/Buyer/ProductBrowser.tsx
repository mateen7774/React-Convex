import {useQuery} from "convex/react";
import {api} from "../../convex/_generated/api";
import ProductCard from "./ProductCard";

export default function ProductBrowser() {
    const allMaterialsMajor = useQuery(api.products.getMaterialsMajor);

    return (
        <>
            <h2>All materials</h2>
            {allMaterialsMajor?.map((materialMajor) => (
                <ProductCard materialMajor={materialMajor} key={materialMajor._id} />
            ))}
        </>
    );
}
