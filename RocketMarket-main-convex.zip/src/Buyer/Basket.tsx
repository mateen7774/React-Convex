import {FormEvent, useEffect, useState} from "react";
import {useAction, useConvexAuth, useQuery} from "convex/react";
import {api} from "../../convex/_generated/api";
import {Form, FormGroup, Input} from "reactstrap";
import "react-datepicker/dist/react-datepicker.css";
import DatePicker from "react-datepicker";
import "../../parameters";
import {MIN_END_TO_END_TIME} from "../../parameters";

export default function Basket() {
    const {isLoading} = useConvexAuth();
    if (isLoading) return "Veuillez patienter...";

    let itemsInBasket = useQuery(api.basket.itemsInBasket);

    console.log(window.location.origin);
    const estimatedPrice = itemsInBasket?.reduce((acc, item) => acc + item.materialMinor!.estimatedPrice * item.quantity, 0);
    const [maxPrice, setMaxPrice] = useState(0);
    const minDeliveryDate = new Date(Date.now() + MIN_END_TO_END_TIME);
    const [deliveryDate, setDeliveryDate] = useState(minDeliveryDate);
    const [deliveryTimeSlot, setDeliveryTimeSlot] = useState(8);
    const [deliveryLocation, setDeliveryLocation] = useState("");
    const [comments, setComments] = useState("");
    const [conditions, setConditions] = useState("");
    const [preventSubmit, setPreventSubmit] = useState(true);
    const initiatePayment = useAction(api.payment.initiatePayment);

    useEffect(() => {
        // if (!itemsInBasket) {
        //     createBasket({});
        //     itemsInBasket = useQuery(api.basket.itemsInBasket);
        // }
        console.log("itemsInBasket updated!");
        if (estimatedPrice) {
            if (maxPrice == 0) setMaxPrice(Math.round(estimatedPrice));
            if (estimatedPrice != 0) setPreventSubmit(false);
        }
    }, [itemsInBasket]);

    const handleFormSubmit = async (e: FormEvent) => {
        e.preventDefault();

        console.log(deliveryDate);

        const redirectUrl = await initiatePayment({
            maxPrice: +maxPrice,
            deliveryLocation: deliveryLocation,
            deliveryDate: deliveryDate.getTime(),
            deliveryTimeSlot: +deliveryTimeSlot,
            comments: comments,
            conditions: conditions,
        });

        console.log(redirectUrl);
        if ("url" in redirectUrl) window.location.href = redirectUrl.url;
        else alert(redirectUrl.error);
    };

    return (
        <>
            <h2>Votre panier</h2>
            <div className="itemRecap">
                {itemsInBasket?.map((item) => {
                    return (
                        <li key={item.materialMinor!._id}>
                            <div>{item.materialMinor!.minorName}</div>
                            <div>{item.quantity}</div>
                        </li>
                    );
                })}
            </div>
            <Form onSubmit={handleFormSubmit}>
                <FormGroup>
                    <div className="deliveryDetails">
                        <div>
                            Delivery date:
                            <DatePicker selected={deliveryDate} onChange={(date: Date) => setDeliveryDate(date)} minDate={minDeliveryDate} />
                        </div>
                        <div>
                            Delivery timeslot:
                            <Input
                                type="select"
                                name="timeSlot"
                                id="timeSlotSelect"
                                value={deliveryTimeSlot}
                                onChange={(e) => setDeliveryTimeSlot(+e.target.value)}
                            >
                                <option value="8">08:00–10:00</option>
                                <option value="10">10:00–12:00</option>
                                <option value="12">12:00–14:00</option>
                                <option value="14">14:00–16:00</option>
                                <option value="16">16:00–18:00</option>
                                <option value="18">18:00–20:00</option>
                            </Input>
                        </div>
                        <div>
                            Delivery address:
                            <Input
                                type="textarea"
                                name="deliveryAddress"
                                id="deliveryAddress"
                                value={deliveryLocation}
                                onChange={(e) => setDeliveryLocation(e.target.value)}
                            />
                        </div>
                        <div>
                            COmments:
                            <Input
                                id="comment"
                                name="comment"
                                type="textarea"
                                value={comments}
                                onChange={(e) => {
                                    setComments(e.target.value);
                                }}
                            />
                        </div>
                        <div>
                            Conditions:
                            <Input
                                id="conditions"
                                name="conditions"
                                type="textarea"
                                value={conditions}
                                onChange={(e) => {
                                    setConditions(e.target.value);
                                }}
                            />
                        </div>
                    </div>
                    <hr />
                    <div className="priceSummary">
                        Suggested maximum price:{" "}
                        <Input type="number" defaultValue={estimatedPrice ? (estimatedPrice / 100).toFixed(2) : ""} readOnly />
                        <br />
                        Your maximum price:
                        <Input type="number" value={(maxPrice / 100).toFixed(2)} onChange={(e) => setMaxPrice(Math.round(+e.target.value * 100))} />
                    </div>
                    <input type="submit" value={`I commit to paying up to ${(maxPrice / 100).toFixed(2)} €`} disabled={preventSubmit} />
                </FormGroup>
            </Form>
        </>
    );
}
