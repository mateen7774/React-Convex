import {useConvexAuth, useQuery} from "convex/react";
import {api} from "../../convex/_generated/api";
import RequestCard from "./RequestCard";

export default function RequestBrowser() {
    const {isLoading} = useConvexAuth();
    if (isLoading) return "Please wait...";
    const userRequests = useQuery(api.bidding.getUserRequests);

    return (
        <>
            <h2>My requests</h2>
            {userRequests?.map((r) => {
                return <RequestCard r={r} key={r._id} />;
            })}
        </>
    );
}
