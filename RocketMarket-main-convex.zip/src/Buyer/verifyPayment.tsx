import {useEffect, useState} from "react";
import {useAction} from "convex/react";
import {api} from "../../convex/_generated/api";
import {useNavigate} from "react-router-dom";

export default function VerifyPayment() {
    const [response, setResponse] = useState({status: "", message: ""});
    const verifyPayment = useAction(api.payment.verifyPayment);
    const navigate = useNavigate();

    useEffect(() => {
        const queryParams = new URLSearchParams(window.location.search);
        const fetchData = async () => {
            const result = await verifyPayment({
                returnMAC: queryParams.get("RETURNMAC")!,
                hostedCheckoutId: queryParams.get("hostedCheckoutId")!,
            });
            result && setResponse(result);
            // if (result && result.status === "success") navigate("/requests");
            // if (result && result.status === "failed") navigate("/basket");
        };

        fetchData();
    }, [verifyPayment]);

    return (
        <>
            Please wait...
            <br />
            {response && <div>{response.status + " " + response.message}</div>}
        </>
    );
}
