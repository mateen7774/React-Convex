export default function RequestDetail() {
    return (
        <>
            <div className="product_detail">
                <h2>Request: XYZ</h2>
            </div>
        </>
    );
}
