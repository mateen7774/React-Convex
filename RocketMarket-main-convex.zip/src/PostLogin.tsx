import {useQuery, useConvexAuth} from "convex/react";
import {useNavigate} from "react-router-dom";
import {api} from "../convex/_generated/api";
import {useEffect} from "react";

export default function PostLogin() {
    const userInfo = useQuery(api.users.getInfo);
    const navigate = useNavigate();
    const {isAuthenticated, isLoading} = useConvexAuth();

    useEffect(() => {
        if (isLoading) {
            return;
        }

        if (!isAuthenticated) {
            navigate("/");
        }

        if (isAuthenticated) {
            if (!userInfo) {
                navigate("/error");
                return;
            }
            if (!userInfo.exists) return navigate("/registration");
            if (!("status" in userInfo)) throw new Error("Existing user does not have status.");
            if (userInfo.status === "PENDING APPROVAL") navigate("/awaiting_approval");
            if (userInfo.status === "SUSPENDED") navigate("/suspended");
            if (userInfo.status === "ACTIVE") {
                if (userInfo.role === "BUYER") navigate("/dashboard");
                if (userInfo.role === "SUPPLIER") navigate("/supplier");
                if (userInfo.role === "ADMIN") navigate("/admin");
            }
        }
    }, [userInfo]);
    return "Please wait...";
}
