import {useAuth0} from "@auth0/auth0-react";
import {FormEvent, useState} from "react";
import {useMutation} from "convex/react";
import {api} from "../convex/_generated/api";
import {useConvexAuth} from "convex/react";

export default function RegistrationForm() {
    const {user} = useAuth0();

    const email = user?.email!;
    const [role, setRole] = useState<"BUYER" | "SUPPLIER">("SUPPLIER");
    const [name, setName] = useState("");
    const [address, setAddress] = useState("");
    const [phone, setPhone] = useState("");
    const [companyRegNumber, setCompanyRegNumber] = useState("");
    const [VATNumber, setVATNumber] = useState("FR");

    const {isLoading, isAuthenticated} = useConvexAuth();
    const registerUser = useMutation(api.users.registerUser);

    async function handleRegistrationFormSubmit(event: FormEvent) {
        event.preventDefault();
        if (isLoading) {
            alert("Loading your credentials...Please try again in a few seconds.");
            return;
        }
        if (!isAuthenticated) {
            console.log("Unauthenticated in RegistrationForm().");
            return;
        }
        await registerUser({
            role,
            name,
            address,
            email,
            phone,
            companyRegNumber: companyRegNumber || undefined,
            VATNumber: VATNumber || undefined,
        });
    }

    return (
        <>
            <h1>Registration</h1>
            <form onSubmit={handleRegistrationFormSubmit}>
                <table>
                    <tbody>
                        <tr>
                            <td>Votre rôle*:</td>
                            <td>
                                <input
                                    type="radio"
                                    name="role"
                                    value="BUYER"
                                    id="radio_role_buyer"
                                    checked={role == "BUYER"}
                                    onChange={(e) => setRole(e.target.value as "BUYER" | "SUPPLIER")}
                                    required
                                />
                                <label htmlFor="radio_role_buyer">Buyer</label>
                                <input
                                    type="radio"
                                    name="role"
                                    value="SUPPLIER"
                                    id="radio_role_supplier"
                                    checked={role == "SUPPLIER"}
                                    onChange={(e) => setRole(e.target.value as "BUYER" | "SUPPLIER")}
                                    required
                                />
                                <label htmlFor="radio_role_supplier">Supplier</label>
                            </td>
                        </tr>
                        <tr>
                            <td>Company name*:</td>
                            <td>
                                <input type="text" name="name" value={name} onChange={(e) => setName(e.target.value)} required />
                            </td>
                        </tr>
                        <tr>
                            <td>Email address*:</td>
                            <td>
                                <input type="text" name="name" value={email ?? ""} readOnly required />
                            </td>
                        </tr>
                        <tr>
                            <td>Address*:</td>
                            <td>
                                <textarea name="address" value={address} onChange={(e) => setAddress(e.target.value)} required />
                            </td>
                        </tr>
                        <tr>
                            <td>Phone number:</td>
                            <td>
                                <input type="text" name="phone" value={phone} onChange={(e) => setPhone(e.target.value)} required />
                            </td>
                        </tr>
                        <tr>
                            <td>Company registration number:</td>
                            <td>
                                <input
                                    type="text"
                                    name="businessRegNumber"
                                    value={companyRegNumber}
                                    onChange={(e) => setCompanyRegNumber(e.target.value)}
                                />
                            </td>
                        </tr>
                        <tr>
                            <td>VAT Number:</td>
                            <td>
                                <input type="text" name="VATNumber" value={VATNumber} onChange={(e) => setVATNumber(e.target.value)} />
                            </td>
                        </tr>
                        <tr>
                            <td></td>
                            <td>
                                <input type="submit" value="Envoyer" />
                            </td>
                        </tr>
                    </tbody>
                </table>
            </form>
        </>
    );
}
