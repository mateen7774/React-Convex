export default function Suspended() {
    return (
        <>
            <h2>Suspended</h2>
            <div>Your account has been suspended. Please contact 123@456.com</div>
        </>
    );
}
