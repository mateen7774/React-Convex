import {Unauthenticated, useQuery} from "convex/react";
import {LoginButton} from "./Auth0Buttons.tsx";
import BuyerNavbar from "./Buyer/BuyerNavbar.tsx";
import SupplierNavbar from "./Supplier/SupplierNavbar.tsx";
import AdminNavbar from "./Admin/AdminNavbar.tsx";
import GenericNavbar from "./GenericNavbar.tsx";
import {api} from "../convex/_generated/api";

export default function Footer() {
    const userInfo = useQuery(api.users.getInfo);

    let navbar = <GenericNavbar />;
    if (userInfo && "role" in userInfo && userInfo?.role === "BUYER") navbar = <BuyerNavbar />;
    else if (userInfo && "role" in userInfo && userInfo?.role === "SUPPLIER") navbar = <SupplierNavbar />;
    else if (userInfo && "role" in userInfo && userInfo?.role === "ADMIN") navbar = <AdminNavbar />;

    return (
        <header>
            <h1
                key="h1"
                style={{
                    backgroundColor: "skyblue",
                }}
            >
                <img src="logo.png" alt="RocketMarket logo" height={100}></img>&nbsp; Rocket Market
                <Unauthenticated>
                    &nbsp;
                    <LoginButton />
                </Unauthenticated>
            </h1>
            {navbar}
        </header>
    );
}
