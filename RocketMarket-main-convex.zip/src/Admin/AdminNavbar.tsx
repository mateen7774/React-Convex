import {NavItem, Nav, Navbar} from "reactstrap";
import {NavLink} from "react-router-dom";

export default function AdminNavbar() {
    return (
        <Navbar>
            <Nav>
                ADMIN
                <NavItem>
                    <NavLink to="/">Home</NavLink>
                </NavItem>
                <NavItem>
                    <NavLink to="/products">Products</NavLink>
                </NavItem>
                <NavItem>
                    <NavLink to="/requests">Requests</NavLink>
                </NavItem>
                <NavItem>
                    <NavLink to="/basket">Basket</NavLink>
                </NavItem>
            </Nav>
        </Navbar>
    );
}
