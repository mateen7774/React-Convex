import {useAuth0} from "@auth0/auth0-react";
import {Authenticated} from "convex/react";
import {LogoutButton} from "./Auth0Buttons.tsx";

export default function Footer() {
    const {user} = useAuth0();

    return (
        <footer
            key="footer"
            style={{
                backgroundColor: "skyblue",
            }}
        >
            <br />
            <br />
            &copy; Rocket Market etc.
            <Authenticated>
                <LogoutButton />
                Email: {user?.email}
            </Authenticated>
        </footer>
    );
}
