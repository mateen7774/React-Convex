import {SECOND, MINUTE, HOUR, DAY} from "../parameters";
import {useEffect, useState} from "react";

export default function Countdown(props: {targetTime: any; staticText: any}) {
    // const fallbackImageUrl = "https://hushed-caiman-696.convex.cloud/api/storage/4b2d6bac-d0e3-4473-aa51-e9219629bf99";

    let retString = "";

    if (props.staticText) retString = props.staticText;
    else {
        const [delta, setDelta] = useState(props.targetTime - Date.now());

        useEffect(() => {
            const interval = setInterval(() => setDelta(props.targetTime - Date.now()), 1000);
            return () => {
                clearInterval(interval);
            };
        });

        const days = Math.floor(delta / DAY);
        if (days != 0) retString += days + "j ";
        const hours = Math.floor((delta - days * DAY) / HOUR);
        retString += hours + "h ";
        const minutes = Math.floor((delta - days * DAY - hours * HOUR) / MINUTE);
        retString += minutes + "m ";
        const seconds = Math.floor((delta - days * DAY - hours * HOUR - minutes * MINUTE) / SECOND);
        retString += seconds + "s";
    }
    return retString;
}
