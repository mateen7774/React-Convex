import {useConvexAuth, useQuery} from "convex/react";
import {api} from "../../convex/_generated/api";
import RequestCard from "./RequestCard";
import {Link} from "react-router-dom";

export default function RequestBrowser() {
    const {isLoading} = useConvexAuth();
    if (isLoading) return "Please wait...";
    const userRequests = useQuery(api.bidding.getAllRequests);

    return (
        <>
            <h2>Requests</h2>
            {userRequests?.map((r) => {
                return (
                    <Link to={"/supplier/requests/" + r._id} key={r._id}>
                        <RequestCard r={r} key={r._id} />
                    </Link>
                );
            })}
        </>
    );
}
