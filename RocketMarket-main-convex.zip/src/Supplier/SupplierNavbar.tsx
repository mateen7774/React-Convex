import {NavItem, Nav, Navbar} from "reactstrap";
import {NavLink} from "react-router-dom";

export default function SupplierNavbar() {
    return (
        <Navbar>
            <Nav>
                Fournisseur
                <NavItem>
                    <NavLink to="/supplier">Home</NavLink>
                </NavItem>
                <NavItem>
                    <NavLink to="/products">Products</NavLink>
                </NavItem>
                <NavItem>
                    <NavLink to="/requests">Requests</NavLink>
                </NavItem>
                <NavItem>
                    <NavLink to="/basket">Basket</NavLink>
                </NavItem>
            </Nav>
        </Navbar>
    );
}
