import {useConvexAuth, useMutation, useQuery} from "convex/react";
import {api} from "../../convex/_generated/api";
import {FormEvent, useEffect, useState} from "react";
import {useParams} from "react-router-dom";
import Countdown from "../Countdown";
import {Form, FormGroup, Input} from "reactstrap";
import {Id} from "../../convex/_generated/dataModel";

export default function RequestDetail() {
    const {isLoading} = useConvexAuth();
    if (isLoading) return "Please wait...";

    const {requestId} = useParams<{requestId: Id<"requests">}>();
    if (!requestId) throw new Error("No requestId passed.");
    const r = useQuery(api.bidding.getRequest, {
        requestId,
    });
    const [offerPrice, setOfferPrice] = useState(0);
    const [offerComments, setOfferComments] = useState("");
    const [preventSubmit, setPreventSubmit] = useState(true);
    const createOffer = useMutation(api.bidding.createOffer);
    const bestOffer = useQuery(api.bidding.getBestOffer, {requestId: requestId});

    console.log(bestOffer);

    const bestOfferPriceElement = bestOffer?.price ? " | Current offer: " + bestOffer?.price + (bestOffer?.isThisUser ? " [Your offer]" : "") : null;

    useEffect(() => {
        if (!requestId || !r) return;
        if (r.status === "NEW") {
            // no existing offer
            if (offerPrice == 0) setOfferPrice(r.maxPrice!);
            setPreventSubmit(false);
        } else if (r.status === "UNDER OFFER") {
            // existing offer, can be underbid
            if (offerPrice == 0 && bestOffer?.price) setOfferPrice(bestOffer?.price - 100);
            setPreventSubmit(false);
        }
    });

    const handleFormSubmit = (e: FormEvent) => {
        e.preventDefault();

        //TODO sanitise
        createOffer({
            requestId: requestId,
            offerPrice: +offerPrice,
            comments: offerComments,
        });
    };

    return (
        <>
            <div className="product_detail">
                <h2>Request for max. {r?.maxPrice} &euro;</h2>
                <div>
                    Status: {r?.status} {bestOfferPriceElement}
                </div>
                <div>To deliver on {new Date(r?.deliveryDate!).toDateString()}</div>
                <div>
                    between {r?.deliveryTimeSlot}h and {(r?.deliveryTimeSlot ?? 0) + 2}h{" "}
                </div>
                <div>to: {r?.deliveryLocation ?? null}</div>
                <div>
                    Timeout: <Countdown targetTime={r?.initialTimeout || null} staticText={r?.initialTimeout ? null : "--h --m --s"} />
                </div>
                <div>
                    Bidding time: <Countdown targetTime={r?.biddingTimeout || null} staticText={r?.biddingTimeout ? null : "48h 00m 00s"} />
                </div>
            </div>
            <hr />
            <FormGroup>
                <Form onSubmit={handleFormSubmit}>
                    Your offer:
                    <Input
                        type="number"
                        value={offerPrice}
                        onChange={(e) => {
                            setOfferPrice(+e.target.value);
                        }}
                    />
                    Comments:
                    <Input
                        type="textarea"
                        value={offerComments}
                        onChange={(e) => {
                            setOfferComments(e.target.value);
                        }}
                    />
                    <Input type="submit" value={`I commit to fulfilling this offer for ${offerPrice} €`} disabled={preventSubmit} />
                </Form>
            </FormGroup>
        </>
    );
}
