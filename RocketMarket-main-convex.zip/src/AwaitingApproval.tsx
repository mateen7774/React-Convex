export default function AwaitingApproval() {
    return (
        <>
            <h2>Awaiting approval</h2>
            <div>Your account is awaiting approval. This may take 24–48h.</div>
        </>
    );
}
