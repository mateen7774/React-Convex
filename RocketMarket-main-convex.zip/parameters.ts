export const SECOND = 1000;
export const MINUTE = 60 * SECOND;
export const HOUR = 60 * MINUTE;
export const DAY = 24 * HOUR;
export const WEEK = 7 * DAY;

export const MAX_BIDDING_TIME = 120 * MINUTE; //48 * HOUR;
export const MIN_FULFIL_TIME = 120 * MINUTE; //1 * WEEK;
export const MAX_INIT_TIMEOUT = 120 * MINUTE; //2 * WEEK;
export const MIN_END_TO_END_TIME = MIN_FULFIL_TIME + MAX_BIDDING_TIME;

export const NOTIFICATION_EMAIL_FROM_ADDR = "RocketMarket <notifications@rocketmarket.app>";
export const NOTIFICATION_EMAIL_TEMPLATE_notifyFormerlySelectedSupplier = "d-ad56bdce59b340e8abfdbaa1bd6891fb";
export const NOTIFICATION_EMAIL_TEMPLATE_notifyBuyerOfBetterOffer = "d-0e1bbcb259dc47b2a48ebe04fe0315f6";
export const NOTIFICATION_EMAIL_TEMPLATE_notifyBuyerOfFirstOffer = "d-81289d0287734ee2830f648bdfc3d839";
export const NOTIFICATION_EMAIL_TEMPLATE_notifyBuyerOfNewRequest = "d-5dcd38f25e774dbbb3837eada1732654";
export const NOTIFICATION_EMAIL_TEMPLATE_notifyBuyerofUnmatchedRequest = "d-161880a84a7e451bbd70d63a9675dfcd";
