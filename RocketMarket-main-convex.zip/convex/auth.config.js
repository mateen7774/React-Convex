export default {
  providers: [
    {
      domain: "jeffhemmen.eu.auth0.com",
      applicationID: "Xz83XCEOdybf6HLUp9F7U9J4lm3v7oeT",
    },
  ]
};
