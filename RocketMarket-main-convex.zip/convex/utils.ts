import {v} from "convex/values";
import {internalMutation, internalQuery} from "./_generated/server";
import {Query, makeFunctionReference} from "convex/server";

export const genericPatch = internalMutation({
    args: {
        id: v.union(v.id("requests"), v.id("payments")),
        patchSet: v.any(),
    },
    handler: async (ctx, args) => {
        await ctx.db.patch(args.id, args.patchSet);
    },
});

export const functionWithQueryContext = internalQuery({
    args: {
        function: v.any(),
        functionParameters: v.optional(v.any()),
    },
    handler: async (ctx, args) => {
        return await args.function(ctx, args.functionParameters);
    },
});
