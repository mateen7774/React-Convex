import {ConvexError, v} from "convex/values";
import {query, mutation, internalMutation} from "../convex/_generated/server";
import {getUserId} from "./users";
import {MAX_BIDDING_TIME, MAX_INIT_TIMEOUT, MIN_FULFIL_TIME} from "../parameters";
import {internal} from "./_generated/api";
import {log as auditLog} from "./audit";
import {Doc, Id} from "./_generated/dataModel";
import {getBasketOrCreateNew} from "./basket";

export const getUserRequests = query({
    args: {},
    handler: async (ctx) => {
        const userId = await getUserId(ctx);
        const requests = ctx.db
            .query("requests")
            .withIndex("by_buyer", (q) => q.eq("buyer", userId))
            .filter((q) => q.or(q.eq(q.field("status"), "NEW"), q.eq(q.field("status"), "UNDER OFFER")))
            .collect();

        return requests;
    },
});

export const getAllRequests = query({
    args: {},
    handler: async (ctx) => {
        const requests = await ctx.db
            .query("requests")
            .filter((q) => q.or(q.eq(q.field("status"), "NEW"), q.eq(q.field("status"), "UNDER OFFER")))
            .collect();
        return requests;
    },
});

export const beginInitialTimeout = async function (ctx: any, requestId: Id<"requests">) {
    const request = await ctx.db.get(requestId);
    if (!request) {
        throw new ConvexError(`bidding:beginInitialTimeout: No such request ${requestId}.`);
    }
    if (!request.deliveryDate) {
        throw new ConvexError(`bidding:beginInitialTimeout: Request ${requestId} has no deliveryDate.`);
    }
    const initialTimeout = Math.min(request.deliveryDate - MIN_FULFIL_TIME, Date.now() + MAX_INIT_TIMEOUT);
    const expireInitialTimeoutScheduledFunction = await ctx.scheduler.runAt(initialTimeout, internal.bidding.expireInitialTimeout, {
        requestId: request._id,
    });
    await ctx.db.patch(request._id, {
        status: "NEW",
        creationTimestamp: Date.now(),
        initialTimeout: initialTimeout,
        expireInitialTimeoutScheduledFunction: expireInitialTimeoutScheduledFunction,
    });
    const patchedRequest = await ctx.db.get(request._id);

    ctx.scheduler.runAfter(0, internal.notifications.notifyBuyerOfNewRequest, {
        request: patchedRequest,
    });

    // TODO ensure user has basket
    getBasketOrCreateNew(ctx);
};

export const expireInitialTimeout = internalMutation({
    args: {requestId: v.id("requests")},
    handler: async (ctx, {requestId}) => {
        auditLog("bidding.expireInitialTimeout", ctx, {requestId});

        // verify that there are no offers

        // set request status to UNMATCHED
        // const request = await ctx.db.get(requestId);
        await ctx.db.patch(requestId, {status: "UNMATCHED"});
    },
});

export const getRequest = query({
    args: {requestId: v.id("requests")},
    handler: async (ctx, {requestId}) => {
        return await ctx.db.get(requestId);
    },
});

export const getBestOffer = query({
    args: {requestId: v.id("requests")},
    handler: async (ctx, {requestId}) => {
        const request = await ctx.db.get(requestId);
        const thisUser = await getUserId(ctx);
        if (!request) throw new ConvexError("No such request (but passed validation?)");
        if (!request.selectedOffer) {
            return {price: request.maxPrice, isThisUser: false};
        }
        const selectedOffer = await ctx.db.get(request.selectedOffer);
        return {price: selectedOffer?.offerPrice, isThisUser: selectedOffer?.supplier === thisUser};
    },
});

export const createOffer = mutation({
    args: {
        requestId: v.id("requests"),
        offerPrice: v.number(),
        comments: v.string(),
    },
    handler: async (ctx, args) => {
        auditLog("bidding.createOffer", ctx, args);

        // TODO check if request still active and before timeout
        // TODO check if new offer lower than existing offers or max price
        const request = await ctx.db.get(args.requestId);
        if (!request) throw new ConvexError("No such request.");

        const supplier = await getUserId(ctx);
        const selectedOffer = request.selectedOffer ? await ctx.db.get(request.selectedOffer) : null;
        const newOffer = await ctx.db.insert("offers", {
            serial: 0,
            status: "ACTIVE",
            request: args.requestId,
            supplier: supplier,
            offerPrice: args.offerPrice,
            comments: args.comments,
        });
        if (args.offerPrice <= request.maxPrice!) {
            if (selectedOffer === null) {
                // it's the first offer
                ctx.scheduler.runAfter(0, internal.notifications.notifyBuyerOfFirstOffer, {
                    request: request,
                    newPrice: args.offerPrice,
                });
                await ctx.db.patch(args.requestId, {selectedOffer: newOffer});
            } else {
                // not the first offer
                if (args.offerPrice < selectedOffer.offerPrice) {
                    // it's an improved offer
                    await ctx.db.patch(args.requestId, {selectedOffer: newOffer});
                    // TODO send notification to buyer, and old selectedOffer supplier
                    const formerOffer = selectedOffer;
                    ctx.scheduler.runAfter(0, internal.notifications.notifyFormerlySelectedSupplier, {
                        request: request,
                        formerOffer: formerOffer,
                        newPrice: args.offerPrice,
                    });
                    ctx.scheduler.runAfter(0, internal.notifications.notifyBuyerOfBetterOffer, {
                        request: request,
                        formerOffer: formerOffer,
                        newPrice: args.offerPrice,
                    });
                } else {
                    // it's not a better offer; log anyway?
                }
            }

            // cancel initialTimeout
            if (request?.expireInitialTimeoutScheduledFunction) {
                await ctx.scheduler.cancel(request.expireInitialTimeoutScheduledFunction);
                const biddingTimeout = Date.now() + MAX_BIDDING_TIME;
                const expireBiddingTimeoutScheduledFunction = await ctx.scheduler.runAt(biddingTimeout, internal.bidding.expireBiddingTimeout, {
                    requestId: args.requestId,
                });
                ctx.db.patch(args.requestId, {
                    initialTimeout: undefined,
                    expireInitialTimeoutScheduledFunction: undefined,
                    biddingTimeout: biddingTimeout,
                    expireBiddingTimeoutScheduledFunction: expireBiddingTimeoutScheduledFunction,
                    status: "UNDER OFFER",
                });
            }
        } else {
            // offer higher than maxPrice
        }
    },
});

export const expireBiddingTimeout = internalMutation({
    args: {requestId: v.id("requests")},
    handler: async (ctx, {requestId}) => {
        auditLog("bidding.expireBiddingTimeout", ctx, {requestId});
        ctx.db.patch(requestId, {status: "SETTLED ON OFFER"});
    },
});

// export const get_user = query({
//     args    : { id : v.id("users") },
//     handler : async (ctx, { id }) => {
//         return await ctx.db.get(id);
//     }
// });

// export const list_users = query({
//     args    : {},
//     handler : async (ctx) => {
//         return await ctx.db.query("users").collect();
//     }
// });
