import {ConvexError, v} from "convex/values";
import {query, mutation, internalQuery} from "../convex/_generated/server";
import {log as auditLog} from "./audit";
import {getBasketOrCreateNew} from "./basket";

export const registerUser = mutation({
    args: {
        role: v.union(v.literal("BUYER"), v.literal("SUPPLIER")), // cannot dreate "admin" via this mutation!
        name: v.string(),
        address: v.string(),
        email: v.string(),
        phone: v.string(),
        companyRegNumber: v.optional(v.string()),
        VATNumber: v.optional(v.string()),
    },
    handler: async (ctx, args) => {
        auditLog("users.registerUser", ctx, args);

        const identity = await ctx.auth.getUserIdentity();
        if (identity === null) {
            throw new Error("Unauthenticated call to mutation `registerUser`.");
        }
        const {tokenIdentifier, email} = identity;
        if (email !== args.email) {
            throw new Error("Form email does not match auth0 email in mutation `registerUser`.");
        }
        ctx.db.insert("users", {
            tokenIdentifier: tokenIdentifier,
            status: "PENDING APPROVAL",
            active: false,
            role: args.role,
            name: args.name,
            address: args.address,
            email: email,
            phone: args.phone,
            companyRegNumber: args.companyRegNumber,
            VATNumber: args.VATNumber,
        });
        getBasketOrCreateNew(ctx); //  ensure basket exists
    },
});

export const getInfo = query({
    args: {},
    handler: async (ctx) => {
        // auditLog("users.getInfo", ctx, {});
        const identity = await ctx.auth.getUserIdentity();
        if (!identity) return null;
        const {tokenIdentifier} = identity;
        const res = await ctx.db
            .query("users")
            .filter((q) => q.eq(q.field("tokenIdentifier"), tokenIdentifier))
            .unique();
        if (!res) return {exists: false};
        return {exists: true, ...res};
    },
});

export const getUserId = async (ctx: any) => {
    // auditLog("users.getUserId", ctx, {});

    const identity = await ctx.auth.getUserIdentity();
    if (!identity) throw new ConvexError("Not authenticated.");

    const {tokenIdentifier} = identity;

    const user = await ctx.db
        .query("users")
        .withIndex("by_tokenIdentifier", (q: any) => q.eq("tokenIdentifier", tokenIdentifier))
        .unique();
    if (!user) throw new ConvexError("No such user.");

    return user._id;
};

export const getById = internalQuery({
    args: {
        userId: v.id("users"),
    },
    handler: async (ctx, {userId}) => {
        // auditLog("users.getById", ctx, {userId});
        return await ctx.db.get(userId);
    },
});
