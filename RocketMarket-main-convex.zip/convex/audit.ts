import {v} from "convex/values";
import {internalMutation} from "./_generated/server";

export const log = async (funcName: string, ctx: any, args: any) => {
    const userIdentity = await ctx.auth.getUserIdentity();
    const logEntry = {funcName: funcName, userIdentity: userIdentity, args: args};
    await ctx.db.insert("audit", logEntry);
};

export const logMutation = internalMutation({
    args: {
        funcName: v.string(),
        ctx: v.any(),
        args: v.optional(v.any()),
    },
    handler: async (ctx, args) => {
        // const logEntry = {funcName: funcName, userIdentity: userIdentity, args: args};
        await ctx.db.insert("audit", {funcName: args.funcName, ctx: args.ctx, args: args.args ? args.args : {}});
    },
});
