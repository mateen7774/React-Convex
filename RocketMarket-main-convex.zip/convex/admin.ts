// import {internalMutation, mutation} from "./_generated/server";

// export const ensureAllUsersHaveABasket = internalMutation({
//     args: {},
//     handler: async (ctx) => {
//         const allUsers = await ctx.db.query("users").collect();
//         for (const user of allUsers) {
//             const existingBasket = await ctx.db
//                 .query("requests")
//                 .withIndex("by_buyer", (q: any) => q.eq("buyer", user._id))
//                 .filter((q) => q.eq(q.field("status"), "BASKET"))
//                 .unique();

//             if (!existingBasket)
//                 await ctx.db.insert("requests", {
//                     serial: 1,
//                     status: "BASKET",
//                     buyer: user._id,
//                 });
//         }
//     },
// });
