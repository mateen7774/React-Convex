import {ConvexError, v} from "convex/values";
import {httpAction, internalMutation, internalQuery, mutation} from "./_generated/server";
import {getBasketOrCreateNew} from "./basket";
import {internal} from "./_generated/api";
import {beginInitialTimeout} from "./bidding";
import {Doc, Id} from "./_generated/dataModel";

// export const registerPayment = internalMutation({
//     args: {
//         basketId: v.id("requests"),
//         returnMac: v.string(),
//         hostedCheckoutId: v.number(),
//     },
//     handler: async (ctx, args) => {
//         await ctx.db.insert("payments", {
//             basketId: args.basketId,
//             returnMac: args.returnMac,
//             hostedCheckoutId: args.hostedCheckoutId,
//         });
//         await ctx.db.patch(args.basketId, {status: "AWAITING_PAYMENT"});
//     },
// });

export const persistAwaitingPayment = internalMutation({
    // mutation so it's atomic!
    args: {
        requestId: v.id("requests"),
        requestPatchSet: v.any(),
        paymentData: v.any(),
    },
    handler: async (ctx, args) => {
        await ctx.db.patch(args.requestId, args.requestPatchSet);
        await ctx.db.insert("payments", {
            status: "LINK_CREATED",
            request: args.requestId,
            returnMAC: args.paymentData.body.RETURNMAC,
            hostedCheckoutId: args.paymentData.body.hostedCheckoutId,
            // data: args.paymentData,
        });
        await getBasketOrCreateNew(ctx); // ensure basket exists
    },
});

export const getPayment = internalQuery({
    args: {
        returnMAC: v.string(),
        hostedCheckoutId: v.string(),
    },
    handler: async (ctx, args) => {
        return await ctx.db
            .query("payments")
            .filter((q) => q.and(q.eq(q.field("returnMAC"), args.returnMAC), q.eq(q.field("hostedCheckoutId"), args.hostedCheckoutId)))
            .unique();
    },
});

export const receiveWebhook = httpAction(async (ctx, request) => {
    let headers: Record<string, string> = {};
    request.headers.forEach((value, key) => {
        headers[key] = value;
    });
    // console.log("Headers:");
    // console.log(headers);
    // let body;
    // try {
    const body = await request.text();
    // } catch (e) {
    //     console.log("Exception: ");
    //     console.log(e);
    //     body = await request.text();
    // }
    // console.log("Body");
    // console.log(body);

    await ctx.scheduler.runAfter(0, internal.payment.receiveWebhook, {requestBody: body, requestHeaders: headers});

    return new Response(null, {
        status: 204,
    });
});

export const getPaymentIdAndRequest = internalQuery({
    args: {
        returnMAC: v.string(),
        hostedCheckoutId: v.string(),
    },
    handler: async (ctx, args) => {
        const payment = await ctx.db
            .query("payments")
            .filter((q) => q.and(q.eq(q.field("returnMAC"), args.returnMAC), q.eq(q.field("returnMAC"), args.returnMAC)))
            .unique();
        if (!payment) throw new ConvexError("No such payment.");
        const request = await ctx.db.get(payment.request);
        return {paymentId: payment._id, request: request};
    },
});

export const validatePayment = internalMutation({
    args: {
        requestId: v.id("requests"),
        paymentId: v.id("payments"),
    },
    handler: async (ctx, args) => {
        beginInitialTimeout(ctx, args.requestId);
        ctx.db.patch(args.paymentId, {status: "CAPTURED"});
        // ensure basket exists TODO
    },
});
