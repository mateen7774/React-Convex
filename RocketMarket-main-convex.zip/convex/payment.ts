"use node";
// import directSdk from "onlinepayments-sdk-nodejs";
const directSdk = require("onlinepayments-sdk-nodejs");

import {ConvexError, v} from "convex/values";
import {action, httpAction, internalAction, internalQuery} from "./_generated/server";
import {getBasket} from "./basket";
import {request} from "http";
import {api, internal} from "./_generated/api";
import {log as auditLog} from "./audit";
import {functionWithQueryContext, genericPatch} from "./utils";
import {Doc, Id} from "./_generated/dataModel";
import {PassThrough} from "stream";
import {X509Certificate} from "crypto";

const WORLDLINE_API_KEY = process.env.WORLDLINE_API_KEY;
const WORLDLINE_API_SECRET = process.env.WORLDLINE_API_SECRET;
const WORLDLINE_PSPID = process.env.WORLDLINE_PSPID;
const WORLDLINE_HOST = process.env.WORLDLINE_HOST;
const WORLDLINE_WEBHOOK_ID = process.env.WORLDLINE_WEBHOOK_ID!;
const WORLDLINE_SECRET_WEBHOOK_KEY = process.env.WORLDLINE_SECRET_WEBHOOK_KEY;
const FRONTEND_DOMAIN = process.env.FRONTEND_DOMAIN;

function getSecretKey(keyId: string, cb: any) {
    if (keyId != WORLDLINE_WEBHOOK_ID) {
        const e = new Error(`could not find secret key for key id ${keyId}`);
        cb(e, null);
    } else {
        cb(null, WORLDLINE_SECRET_WEBHOOK_KEY);
    }
}

const client = directSdk.init({
    host: WORLDLINE_HOST,
    apiKeyId: WORLDLINE_API_KEY,
    secretApiKey: WORLDLINE_API_SECRET,
    integrator: "OnlinePayments",
});
directSdk.webhooks.init({
    getSecretKey: getSecretKey,
});

export const initiatePayment = action({
    args: {
        maxPrice: v.number(),
        deliveryLocation: v.string(),
        deliveryDate: v.number(),
        deliveryTimeSlot: v.number(),
        comments: v.string(),
        conditions: v.string(),
    },
    handler: async (ctx, args) => {
        const basket: Doc<"requests"> = await ctx.runQuery(internal.basket.getBasket_IQ);

        const createHostedCheckoutRequest = {
            order: {
                amountOfMoney: {
                    amount: args.maxPrice,
                    currencyCode: "EUR",
                },
                references: {
                    descriptor: "RocketMarket Request",
                    merchantReference: basket._id,
                },
                shipping: {
                    emailAddress: "test@citrusfruit.lu",
                    addressIndicator: "different-than-billing",
                    type: "address.type",
                    address: {
                        city: "Esch",
                    },
                },
            },
            redirectPaymentMethodSpecificInput: {
                redirectionData: {
                    returnUrl: FRONTEND_DOMAIN + "/verifyPayment",
                },
                paymentProduct5408SpecificInput: {
                    instantPaymentOnly: true,
                },
                // paymentProductId: 5408,
            },
            hostedCheckoutSpecificInput: {
                returnUrl: FRONTEND_DOMAIN + "/verifyPayment",
                locale: "fr_FR",
                paymentProductFilters: {
                    restrictTo: {
                        products: [711], //1, 3, 130, 771, 5408],
                    },
                },
                cardPaymentMethodSpecificInput: {
                    groupCards: false,
                },
                variant: "SimplifiedCustomPaymentPage",
            },
            cardPaymentMethodSpecificInput: {
                authorizationMode: "SALE",
            },
            sepaDirectDebitPaymentMethodSpecificInput: {
                paymentProduct771SpecificInput: {
                    mandate: {
                        returnUrl: "https://secure.ogone.com/ncol/test/displayparams.asp",
                        customer: {
                            // Hide this fields to show the form on the payment page
                            //"bankAccountIban": {
                            //  "iban": "BE45000253450589"
                            //},
                            companyName: "Ingenico",
                            contactDetails: {
                                emailAddress: "test@ogone.com",
                            },
                            mandateAddress: {
                                city: "Zaventem",
                                countryCode: "BE",
                                street: "Leonardo da Vincilaan 3",
                                zip: "1930",
                            },
                            personalInformation: {
                                name: {
                                    firstName: "Raphael",
                                    surname: "Magoteau",
                                },
                                title: "Mr",
                            },
                        },
                        customerReference: "0efaa98944324234b9ad27f9355a1093",
                        language: "en",
                        recurrenceType: "RECURRING",
                        signatureType: "SMS", // or SMS
                        uniqueMandateReference: "mandateRef_{{$timestamp}}",
                    },
                },
            },
            // paymentProduct5408SpecificInput: {
            //     instantPaymentOnly: true,
            // },
        };

        // console.log(createHostedCheckoutRequest);

        const createHostedCheckoutResponse = await client.hostedCheckout.createHostedCheckout(WORLDLINE_PSPID, createHostedCheckoutRequest, null);

        console.log(createHostedCheckoutResponse);
        console.log(createHostedCheckoutResponse.body.errors);

        await ctx.runMutation(internal.payment_utils.persistAwaitingPayment, {
            requestId: basket._id,
            requestPatchSet: args,
            paymentData: createHostedCheckoutResponse,
        });

        if (createHostedCheckoutResponse.isSuccess) {
            return {url: createHostedCheckoutResponse.body.redirectUrl};
        } else {
            return {error: "Unexpected error."};
        }
    },
});

export const verifyPayment = action({
    args: {
        returnMAC: v.string(),
        hostedCheckoutId: v.string(),
    },
    handler: async (ctx, args) => {
        let hostedCheckoutStatus;
        try {
            hostedCheckoutStatus = await client.hostedCheckout.getHostedCheckout(WORLDLINE_PSPID, args.hostedCheckoutId, null);
        } catch (e) {
            console.log(e);
            return {status: "failed", message: "Error talking to payment API."};
        }

        console.log(hostedCheckoutStatus);
        console.log(hostedCheckoutStatus.body.createdPaymentOutput.payment);

        // const status = hostedCheckoutStatus.body.createdPaymentOutput.payment.status;

        const paymentIdAndRequest = await ctx.runQuery(internal.payment_utils.getPaymentIdAndRequest, args);
        const {paymentId, request} = paymentIdAndRequest;

        // console.log(status);
        // const paymentInDB = await ctx.runQuery(internal.payment_utils.getPayment, {...args});
        // printNestedObject(hostedCheckoutStatus);
        console.log({paymentId, request});
        if (!request) throw new ConvexError("No such request.");

        const requestStatus: string = request.status;
        if (request.status === "NEW") return {status: "success", message: "Request already live."};
        if (request.status != "BASKET") return {status: "error", message: `Request neither NEW nor BASKET, but status=${requestStatus}.`};

        if (
            hostedCheckoutStatus.body.createdPaymentOutput.payment.status === "CAPTURED" &&
            hostedCheckoutStatus.body.createdPaymentOutput.payment.paymentOutput.amountOfMoney.amount === request.maxPrice &&
            hostedCheckoutStatus.body.createdPaymentOutput.payment.paymentOutput.amountOfMoney.currencyCode === "EUR" &&
            hostedCheckoutStatus.body.createdPaymentOutput.payment.paymentOutput.references.merchantReference === request._id
        ) {
            await ctx.runMutation(internal.payment_utils.validatePayment, {requestId: request._id, paymentId: paymentId});
            return {status: "success", message: "Payment succeeded."};
        } else {
            console.log("Payment verification failed.");
            return {status: "failed", message: "Error reconciling payment."};
        }
        // TODO verify if authenticated user is request.buyer!
    },
});

export const receiveWebhook = internalAction({
    args: {
        requestBody: v.any(),
        requestHeaders: v.any(),
    },
    handler: async (ctx, {requestBody, requestHeaders}) => {
        directSdk.webhooks.unmarshal(requestBody, requestHeaders, (error: any, event: any) => {
            if (error) {
                // something went wrong in validating the signature or unmarshalling the event
                console.log("error");
                console.log(error);
            } else {
                console.log("event");
                // printNestedObject(event);
            }
        });
    },
});
