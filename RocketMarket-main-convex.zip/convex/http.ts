import {httpRouter} from "convex/server";
import {receiveWebhook} from "./payment_utils";

const http = httpRouter();

http.route({
    path: "/notify",
    method: "POST",
    handler: receiveWebhook,
});

// Convex expects the router to be the default export of `convex/http.js`.
export default http;
