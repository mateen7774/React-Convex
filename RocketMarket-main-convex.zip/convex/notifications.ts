"use node";
import sgMail from "@sendgrid/mail";
import {internalAction} from "./_generated/server";
import {ConvexError, v} from "convex/values";
import {api, internal} from "./_generated/api";
import {
    NOTIFICATION_EMAIL_FROM_ADDR,
    NOTIFICATION_EMAIL_TEMPLATE_notifyBuyerOfBetterOffer,
    NOTIFICATION_EMAIL_TEMPLATE_notifyBuyerOfFirstOffer,
    NOTIFICATION_EMAIL_TEMPLATE_notifyBuyerOfNewRequest,
    NOTIFICATION_EMAIL_TEMPLATE_notifyBuyerofUnmatchedRequest,
    NOTIFICATION_EMAIL_TEMPLATE_notifyFormerlySelectedSupplier,
} from "../parameters";

sgMail.setApiKey(process.env.SENDGRID_API_KEY!);

export const notifyFormerlySelectedSupplier = internalAction({
    args: {
        request: v.any(),
        formerOffer: v.any(),
        newPrice: v.number(),
    },
    handler: async (ctx, {request, formerOffer, newPrice}) => {
        // auditLog("notifications.notifyFormerlySelectedSupplier", ctx, {request, formerOffer, newPrice});

        // const supplier = await ctx.runQuery(internal.users.getById, {userId: formerOffer.supplier});
        // const numRequestItems = await ctx.runQuery(api.basket.getNumItems, {requestId: request._id});

        const [supplier, numRequestItems] = await Promise.all([
            ctx.runQuery(internal.users.getById, {userId: formerOffer.supplier}),
            ctx.runQuery(api.basket.getNumItems, {requestId: request._id}),
        ]);
        if (!supplier) throw new ConvexError(`No supplier {formerOffer.supplier} for former offer {formerOffer._id} in request {request._id}.`);

        const msg = {
            to: supplier.email,
            from: NOTIFICATION_EMAIL_FROM_ADDR,
            templateId: NOTIFICATION_EMAIL_TEMPLATE_notifyFormerlySelectedSupplier,
            dynamic_template_data: {
                formerOfferPrice: formerOffer.offerPrice,
                requestId: request._id,
                numRequestItems: numRequestItems,
                requestDeliveryLocation: request.deliveryLocation,
                requestDeliveryDate: new Date(request.deliveryDate).toDateString(),
                newOfferPrice: newPrice,
            },
        };
        await sgMail
            .send(msg)
            .then(() => {
                console.log("notifyFormerlySelectedSupplier Email sent");
            })
            .catch((error) => {
                throw new ConvexError(error);
            });
    },
});

export const notifyBuyerOfFirstOffer = internalAction({
    args: {
        request: v.any(),
        newPrice: v.number(),
    },
    handler: async (ctx, {request, newPrice}) => {
        // auditLog("notifications.notifyBuyerOfFirstOffer", ctx, {request, formerOffer, newPrice});

        const [buyer, numRequestItems] = await Promise.all([
            ctx.runQuery(internal.users.getById, {userId: request.buyer}),
            ctx.runQuery(api.basket.getNumItems, {requestId: request._id}),
        ]);
        if (!buyer) throw new ConvexError(`No buyer {request.buyer} for request {request._id}.`);

        const msg = {
            to: buyer.email,
            from: NOTIFICATION_EMAIL_FROM_ADDR,
            templateId: NOTIFICATION_EMAIL_TEMPLATE_notifyBuyerOfFirstOffer,
            dynamic_template_data: {
                requestId: request._id,
                numRequestItems: numRequestItems,
                requestDeliveryLocation: request.deliveryLocation,
                requestDeliveryDate: new Date(request.deliveryDate).toDateString(),
                newOfferPrice: newPrice,
                requestMaxPrice: request.maxPrice,
            },
        };
        console.log(msg);
        await sgMail
            .send(msg)
            .then(() => {
                console.log("notifyBuyerOfFirstOffer Email sent");
            })
            .catch((error) => {
                throw new ConvexError(error);
            });
    },
});

export const notifyBuyerOfBetterOffer = internalAction({
    args: {
        request: v.any(),
        formerOffer: v.any(),
        newPrice: v.number(),
    },
    handler: async (ctx, {request, formerOffer, newPrice}) => {
        // auditLog("notifications.notifyBuyerOfBetterOffer", ctx, {request, formerOffer, newPrice});

        const [buyer, numRequestItems] = await Promise.all([
            ctx.runQuery(internal.users.getById, {userId: request.buyer}),
            ctx.runQuery(api.basket.getNumItems, {requestId: request._id}),
        ]);
        if (!buyer) throw new ConvexError(`No buyer {request.buyer} for request {request._id}.`);

        const msg = {
            to: buyer.email,
            from: NOTIFICATION_EMAIL_FROM_ADDR,
            templateId: NOTIFICATION_EMAIL_TEMPLATE_notifyBuyerOfBetterOffer,
            dynamic_template_data: {
                requestId: request._id,
                newOfferPrice: newPrice,
                formerOfferPrice: formerOffer.offerPrice,
                numRequestItems: numRequestItems,
                requestDeliveryDate: new Date(request.deliveryDate).toDateString(),
                requestDeliveryLocation: request.deliveryLocation,
            },
        };
        await sgMail
            .send(msg)
            .then(() => {
                console.log("notifyBuyerOfBetterOffer Email sent");
            })
            .catch((error) => {
                throw new ConvexError(error);
            });
    },
});

export const notifyBuyerOfNewRequest = internalAction({
    args: {
        request: v.any(),
    },
    handler: async (ctx, {request}) => {
        // auditLog("notifications.notifyBuyerOfNewRequest", ctx, {request, formerOffer, newPrice});

        const [buyer, numRequestItems] = await Promise.all([
            ctx.runQuery(internal.users.getById, {userId: request.buyer}),
            ctx.runQuery(api.basket.getNumItems, {requestId: request._id}),
        ]);
        if (!buyer) throw new ConvexError(`No buyer {request.buyer} for request {request._id}.`);

        const msg = {
            to: buyer.email,
            from: NOTIFICATION_EMAIL_FROM_ADDR,
            templateId: NOTIFICATION_EMAIL_TEMPLATE_notifyBuyerOfNewRequest,
            dynamic_template_data: {
                requestId: request._id,
                numRequestItems: numRequestItems,
                requestDeliveryDate: new Date(request.deliveryDate).toDateString(),
                requestDeliveryLocation: request.deliveryLocation,
                requestMaxPrice: request.maxPrice,
            },
        };
        await sgMail
            .send(msg)
            .then(() => {
                console.log("notifyBuyerOfNewRequest Email sent");
            })
            .catch((error) => {
                throw new ConvexError(error);
            });
    },
});

export const notifyBuyerofUnmatchedRequest = internalAction({
    args: {
        request: v.any(),
    },
    handler: async (ctx, {request}) => {
        // auditLog("notifications.notifyBuyerofUnmatchedRequest", ctx, {request, formerOffer, newPrice});

        const numRequestItems = await ctx.runQuery(api.basket.getNumItems, {requestId: request._id});

        const buyer = await ctx.runQuery(internal.users.getById, {userId: request.buyer});
        if (!buyer) throw new ConvexError(`No buyer {request.buyer} for request {request._id}.`);

        const msg = {
            to: buyer.email,
            from: NOTIFICATION_EMAIL_FROM_ADDR,
            templateId: NOTIFICATION_EMAIL_TEMPLATE_notifyBuyerofUnmatchedRequest,
            dynamic_template_data: {
                requestId: request._id,
                numRequestItems: numRequestItems,
                requestDeliveryDate: new Date(request.deliveryDate).toDateString(),
                requestDeliveryLocation: request.deliveryLocation,
                requestMaxPrice: request.maxPrice,
            },
        };
        await sgMail
            .send(msg)
            .then(() => {
                console.log("notifyBuyerofUnmatchedRequest Email sent");
            })
            .catch((error) => {
                throw new ConvexError(error);
            });
    },
});
