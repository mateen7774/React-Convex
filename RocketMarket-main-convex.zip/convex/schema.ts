import {defineSchema, defineTable} from "convex/server";
import {v} from "convex/values";

export default defineSchema(
    {
        users: defineTable({
            VATNumber: v.optional(v.string()),
            active: v.optional(v.boolean()),
            address: v.string(),
            companyRegNumber: v.optional(v.string()),
            email: v.string(),
            name: v.string(),
            phone: v.string(),
            role: v.union(v.literal("BUYER"), v.literal("SUPPLIER"), v.literal("ADMIN")),
            status: v.union(v.literal("PENDING APPROVAL"), v.literal("ACTIVE"), v.literal("SUSPENDED")),
            tokenIdentifier: v.string(),
        }).index("by_tokenIdentifier", ["tokenIdentifier"]),
        requests: defineTable({
            serial: v.number(),
            status: v.union(
                v.literal("BASKET"),
                v.literal("SUBMITTING"),
                v.literal("AWAITING_PAYMENT"),
                v.literal("NEW"),
                v.literal("UNMATCHED"),
                v.literal("UNDER OFFER"),
                v.literal("FULFILLED"),
                v.literal("SETTLED ON OFFER"),
                v.literal("NEW REQUEST CANCELED"),
                v.literal("SETTLED OFFER CANCELED"),
                v.literal("ACTIVE REQUEST CANCELED"),
                v.literal("SETTLED REQUEST CANCELED"),
                v.literal("DISPUTE"),
                v.literal("DISPUTE RESOLVED")
            ),
            // active: v.optional(v.boolean()),
            buyer: v.id("users"),
            maxPrice: v.optional(v.number()),
            creationTimestamp: v.optional(v.number()),
            deliveryLocation: v.optional(v.string()),
            deliveryDate: v.optional(v.number()),
            deliveryTimeSlot: v.optional(v.number()),
            comments: v.optional(v.string()),
            conditions: v.optional(v.string()),
            selectedOffer: v.optional(v.id("offers")),
            initialTimeout: v.optional(v.number()),
            expireInitialTimeoutScheduledFunction: v.optional(v.id("_scheduled_functions")),
            biddingTimeout: v.optional(v.number()),
            expireBiddingTimeoutScheduledFunction: v.optional(v.id("_scheduled_functions")),
        })
            .index("by_buyer", ["buyer"])
            .index("by_buyer_and_status", ["buyer", "status"]),
        offers: defineTable({
            serial: v.number(),
            status: v.union(v.literal("ACTIVE"), v.literal("ADMIN OVERRIDE")),
            request: v.id("requests"),
            supplier: v.id("users"),
            offerPrice: v.number(),
            comments: v.optional(v.string()),
        })
            .index("by_request", ["request"])
            .index("by_supplier", ["supplier"]),
        materialsMajor: defineTable({
            majorName: v.string(),
            majorDescription: v.string(),
            imageUrl: v.optional(v.string()),
        }).index("by_majorName", ["majorName"]),
        materialsMinor: defineTable({
            materialMajor: v.id("materialsMajor"),
            minorName: v.string(),
            minorDescription: v.string(),
            estimatedPrice: v.number(),
            parameters: v.array(v.object({priority: v.number(), name: v.string(), value: v.string()})),
        }).index("by_materialMajor", ["materialMajor"]),
        requestItems: defineTable({
            request: v.id("requests"),
            item: v.id("materialsMinor"),
            quantity: v.number(),
        }).index("by_request", ["request"]),
        payments: defineTable({
            request: v.id("requests"),
            hostedCheckoutId: v.string(),
            returnMAC: v.string(),
            status: v.union(v.literal("LINK_CREATED"), v.literal("CAPTURED")),
        }),
        audit: defineTable({
            funcName: v.string(),
            ctx: v.any(),
            args: v.any(),
        }),
    },
    {
        strictTableNameTypes: false,
        schemaValidation: false,
    }
);
