import {v, ConvexError} from "convex/values";
import {query, mutation, internalQuery} from "./_generated/server";
import "../parameters";
import {log as auditLog} from "./audit";
import {Doc} from "./_generated/dataModel";

export const getBasketOrCreateNew = async (ctx: any) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) throw new ConvexError("Not authenticated.");

    const {tokenIdentifier} = identity;

    const user = await ctx.db
        .query("users")
        .withIndex("by_tokenIdentifier", (q: any) => q.eq("tokenIdentifier", tokenIdentifier))
        .unique();
    if (!user) throw new ConvexError("No such user.");

    const existingBasket = await ctx.db
        .query("requests")
        .withIndex("by_buyer_and_status", (q: any) => q.eq("buyer", user._id).eq("status", "BASKET"))
        .unique();

    if (existingBasket) return existingBasket;

    // create new basket
    const newBasketData = {
        serial: 1,
        status: "BASKET",
        buyer: user._id,
    };
    const newBasketId = await ctx.db.insert("requests", newBasketData);
    return {...newBasketData, _id: newBasketId};
};

export const getBasket = async (ctx: any) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) throw new ConvexError("Not authenticated.");

    const {tokenIdentifier} = identity;

    const user = await ctx.db
        .query("users")
        .withIndex("by_tokenIdentifier", (q: any) => q.eq("tokenIdentifier", tokenIdentifier))
        .unique();
    if (!user) throw new ConvexError("No such user.");

    const existingBasket = await ctx.db
        .query("requests")
        .withIndex("by_buyer_and_status", (q: any) => q.eq("buyer", user._id).eq("status", "BASKET"))
        .unique();

    if (existingBasket) return existingBasket;
    else throw new ConvexError("No such basket.");
};

export const createBasket = mutation({
    args: {},
    handler: async (ctx) => {
        await getBasketOrCreateNew(ctx);
        console.log("Created basket.");
    },
});

export const itemsInBasket = query({
    args: {},
    handler: async (ctx) => {
        let basket: Doc<"requests">;
        try {
            basket = await getBasket(ctx);
        } catch (e) {
            throw new ConvexError("No such basket.");
        }

        const requestItems = await ctx.db
            .query("requestItems")
            .withIndex("by_request", (q) => q.eq("request", basket._id))
            .collect();

        const retArray = await Promise.all(
            requestItems.map(async (requestItem) => {
                const materialMinor = await ctx.db.get(requestItem.item);
                return {quantity: requestItem.quantity, materialMinor};
            })
        );

        return retArray;
    },
});

export const addToBasket = mutation({
    args: {
        materialMinor: v.id("materialsMinor"),
        quantity: v.number(),
    },
    handler: async (ctx, args) => {
        auditLog("products.addToBasket", ctx, args);

        const basket = await getBasketOrCreateNew(ctx);

        const existingItemInBasket = await ctx.db
            .query("requestItems")
            .withIndex("by_request", (q) => q.eq("request", basket._id))
            .filter((q) => q.eq(q.field("item"), args.materialMinor))
            .unique();

        if (existingItemInBasket) {
            await ctx.db.patch(existingItemInBasket._id, {
                quantity: existingItemInBasket.quantity + args.quantity,
            });
        } else {
            ctx.db.insert("requestItems", {
                request: basket._id,
                item: args.materialMinor,
                quantity: args.quantity,
            });
        }
    },
});

export const getNumItems = query({
    args: {
        requestId: v.id("requests"),
    },
    handler: async (ctx, {requestId}) => {
        const requestItems = await ctx.db
            .query("requestItems")
            .withIndex("by_request", (q) => q.eq("request", requestId))
            .collect();
        return requestItems.reduce((acc, e) => acc + e.quantity, 0);
    },
});

export const getBasket_IQ = internalQuery({
    args: {},
    handler: async (ctx) => {
        return await getBasket(ctx);
    },
});

export const saveBasket = mutation({
    args: {
        maxPrice: v.number(),
        deliveryLocation: v.string(),
        deliveryDate: v.number(),
        deliveryTimeSlot: v.number(),
        comments: v.string(),
        conditions: v.string(),
    },
    handler: async (ctx, args) => {
        auditLog("products.saveBasket", ctx, args);
        const request = await getBasket(ctx);

        ctx.db.patch(request._id, {
            maxPrice: args.maxPrice,
            deliveryLocation: args.deliveryLocation,
            deliveryTimeSlot: args.deliveryTimeSlot,
            deliveryDate: args.deliveryDate,
            comments: args.comments,
            conditions: args.conditions,
        });
    },
});
