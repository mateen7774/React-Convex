import {v} from "convex/values";
import {query, mutation} from "./_generated/server";
import {internal} from "./_generated/api";
import "../parameters";
import {MAX_INIT_TIMEOUT, MIN_FULFIL_TIME} from "../parameters";
import {log as auditLog} from "./audit";
import {getBasketOrCreateNew, getBasket} from "./basket";

export const getCombinations = query({
    args: {
        materialMajor: v.id("materialsMajor"),
    },
    handler: async (ctx, {materialMajor}) => {
        const identity = await ctx.auth.getUserIdentity();
        if (!identity) return null;

        const {majorName, majorDescription} = (await ctx.db.get(materialMajor))!;
        const returnMap = {majorName, majorDescription, materialsMinor: Array()};

        const allMinors = await ctx.db
            .query("materialsMinor")
            .withIndex("by_materialMajor", (q) => q.eq("materialMajor", materialMajor))
            .collect();
        returnMap.materialsMinor.push(...allMinors);

        // console.log(returnMap);

        return returnMap;
    },
});

export const getMaterialsMajor = query({
    args: {},
    handler: async (ctx) => {
        const identity = await ctx.auth.getUserIdentity();
        if (!identity) return null;

        return await ctx.db.query("materialsMajor").collect();
    },
});

// export const submitRequest = mutation({
//     args: {
//         maxPrice: v.number(),
//         deliveryLocation: v.string(),
//         deliveryDate: v.number(),
//         deliveryTimeSlot: v.number(),
//         comments: v.string(),
//         conditions: v.string(),
//     },
//     handler: async (ctx, args) => {
//         auditLog("products.submitRequest", ctx, args);
//         const request = await getBasket(ctx);

//         const initialTimeout = Math.min(args.deliveryDate - MIN_FULFIL_TIME, Date.now() + MAX_INIT_TIMEOUT);
//         const expireInitialTimeoutScheduledFunction = await ctx.scheduler.runAt(initialTimeout, internal.bidding.expireInitialTimeout, {
//             requestId: request._id,
//         });

//         await ctx.db.patch(request._id, {
//             // status: "SUBMITTING",
//             maxPrice: args.maxPrice,
//             deliveryLocation: args.deliveryLocation,
//             deliveryTimeSlot: args.deliveryTimeSlot,
//             deliveryDate: args.deliveryDate,
//             comments: args.comments,
//             conditions: args.conditions,
//             creationTimestamp: Date.now(),
//             initialTimeout: initialTimeout,
//             expireInitialTimeoutScheduledFunction: expireInitialTimeoutScheduledFunction,
//         });
//         const patchedRequest = await ctx.db.get(request._id);

//         ctx.scheduler.runAfter(0, internal.notifications.notifyBuyerOfNewRequest, {
//             request: patchedRequest,
//         });

//         await getBasketOrCreateNew(ctx); // ensure basket exists again;  TODO remove `await`?
//     },
// });
